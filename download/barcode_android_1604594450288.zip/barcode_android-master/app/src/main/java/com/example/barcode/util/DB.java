package com.example.barcode.util;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import com.example.barcode.object.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import androidx.annotation.NonNull;

public class DB {
    static String TAG = "FIRESTORE";
    public static void addUser(final Context context, final User u){



    }
}
