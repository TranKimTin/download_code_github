package com.example.caro;

public class Point{
    public int x, y;
    void set(int r, int c){
        x = r;
        y = c;
    }
    Point(){}
    Point(int r, int c){
        x = r;
        y = c;
    }
};
